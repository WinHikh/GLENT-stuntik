# GLENT VPN PITBIKE STUNT — Godot 4.3

3D-прототип игры для Android: арена, питбайк, экранные кнопки, трамплины и переключение камер.

## Сборка APK через GitHub Actions (можно с телефона)

1. Помести этот ZIP в корень GitHub-репозитория.
2. В репозитории должен быть файл `.github/workflows/build-apk.yml` с workflow из этого архива. GitHub не запускает workflow, пока он находится только внутри ZIP.
3. Удали старые ZIP-архивы из корня репозитория или замени ими старый архив: workflow выбирает первый ZIP по имени.
4. Открой Actions → `GLENT VPN PITBIKE - Android APK` → Run workflow.
5. После успешного запуска открой страницу запуска и скачай `GLENT-VPN-Pitbike-APK` в разделе Artifacts.

Workflow устанавливает Godot 4.3, его Android export templates, Java 17, Android SDK 34, NDK r23c и CMake. APK подписывается временным debug-ключом для тестовой установки.

## Важно

Это игровой прототип, а не готовый релиз. Сборку нужно подтвердить реальным запуском GitHub Actions; в этой среде сам Godot Android export не запускался.
